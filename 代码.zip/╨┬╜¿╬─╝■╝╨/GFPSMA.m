%
%    GFASMA-An improved algorithm based on flower pollination, slime mould and game inspiration for global optimization
%    Contirbution:
%    author : by Wenqing Xiong
%    date: 2023/10/13

function [bestSolution,bestFitValue,cg_curve]=GFPSMA(N,Max_iter,lb,ub,dim,fobj)
p = 0.4;
cg_curve=zeros(1,dim);
AllFitness = inf*ones(N,1);
weight = ones(N,dim);
Destination_fitness=inf;
z=0.3;
d=dim;
Lb = lb.*ones(1,d);
Ub= ub.*ones(1,d);     
for i=1:N
    Sol(i,:)=Lb+(Ub-Lb).*rand(1,d);
    Fitness(i)=fobj(Sol(i,:));
end
[fmin,I]=min(Fitness);
best=Sol(I,:);
S=Sol;
X=Sol;
InitTemperture = 10000;   
CoefDecT = 0.99;   

for t=1:Max_iter   
    for i=1:N
        if rand>p 
            Br=randn(1,dim);
            
            gold=double((sqrt(5)-1)/2);     
            aa=1-t*((1)/Max_iter);
            b=1;
            x1=aa+(1-gold)*(b-aa);         
            x2=aa+gold*(b-aa);              
            S(i,:)=x1*Sol(i,:)+x2*best+Br.*Levy(d).*(Sol(i,:)-best);       
            S(i,:)=simplebounds(S(i,:),Lb,Ub);
        else
            epsilon=rand;
            JK=randperm(N);
            S(i,:)=Sol(i,:)+epsilon*(Sol(JK(1),:)-Sol(JK(2),:));
            S(i,:)=simplebounds(S(i,:),Lb,Ub);
        end

        Fnew=fobj(S(i,:));
        if (Fnew<=Fitness(i))
            Sol(i,:)=S(i,:);
            Fitness(i)=Fnew;
        end
    end
    bestPositions=best;
    for i=1:N
        Flag4ub=X(i,:)>ub;
        Flag4lb=X(i,:)<lb;
        X(i,:)=(X(i,:).*(~(Flag4ub+Flag4lb)))+ub.*Flag4ub+lb.*Flag4lb;
        Fitness(i)=fobj(X(i,:));
    end
    [SmellOrder,SmellIndex] = sort(AllFitness);  
    worstFitness = SmellOrder(N);
    bestFitness = SmellOrder(1);
    SS=bestFitness-worstFitness+eps;
    for i=1:N
        for j=1:dim
            if i<=(N/2)
                weight(SmellIndex(i),j) = 1+rand()*log10((bestFitness-SmellOrder(i))/(SS)+1);
            else
                weight(SmellIndex(i),j) = 1-rand()*log10((bestFitness-SmellOrder(i))/(SS)+1);
            end
        end
    end
    if bestFitness < Destination_fitness
        bestPositions=X(SmellIndex(1),:);
        Destination_fitness = bestFitness;
    end
    a = atanh(-(t/Max_iter)+1);   
    b = 1-t/Max_iter;
    %     b=(1-(t/Max_iter).^2).^2;
    for i=1:N
        Xmean = mean(X);
        if rand<z  
            X(i,:)  = (Ub-Lb)*rand+Lb;
            rij1=norm(X(i,:)-bestPositions);
            rij2=norm(X(i,:)-Xmean);
            if rand<0.5*z
                alphe1=exp(-rij1^2);
                X0= X(i,:) +alphe1;
                if fobj(X0)<fobj(X(i,:))
                    X(i,:)=X0;
                end
            elseif rand>0.5*z && rand<z
                alphe2=exp(-rij2^2);
                X1=X(i,:) +alphe2;
                if fobj(X1)<fobj(X(i,:))
                    X(i,:)=X1;
                end
            end   
        else
            pp =tanh(abs(AllFitness(i)-Destination_fitness)); 
            vb = unifrnd(-a,a,1,dim);
            vc = unifrnd(-b,b,1,dim);
            for j = 1:dim
                r = rand();
                A = randi([1,N]); 
                B = randi([1,N]);
                if r<pp
                    X(i,j) = bestPositions(j)+ vb(j)*(weight(i,j).*X(A,j)-X(B,j));
                else
                    X(i,j) = vc(j)*X(i,j);
                end
            end
            
        end
    end
    for i =1:N
        fitSol =fobj(Sol(i,:));
        fitX=fobj(X(i,:));
        if fitSol<= fitX
            TempPop(i,:)=Sol(i,:);
        else
            TempPop(i,:)=X(i,:);
        end
        %     changer1 = -1 *(fitX-fitSol)/InitTemperture;
        %     sap = exp(changer1);
        %     if sap==inf
        %         sap=0.01;
        %     end
        %     sapvector(i)=sap;
        if 0.02>rand
            player_values = [int32(fitSol),int32(fitX)];
            fff = @(Sy) sum(player_values(Sy));
            shapley_values  = calculateShapleyValueTwoPlayers(fff);
            if shapley_values(1) >= shapley_values(2)
                TempPop(i,:)=X(i,:);
            else
                TempPop(i,:)=Sol(i,:);
            end
        end
        TFitness(i) =fobj(TempPop(i,:));
    end
    %     InitTemperture = InitTemperture * CoefDecT;
    Sol=TempPop;
    X=TempPop;
    [fmin1,II]=min(TFitness);
    best=TempPop(II,:);
    X_new_bestpos_fit =fobj(best);
    if abs(X_new_bestpos_fit-Fitness(i))>exp(t/Max_iter)^(-6)  
        uu=S(i,:)/norm(S(i,:));
        uu=uu';
        H=eye(dim)-2*(uu*uu'); 
        Positions_ref=S*H; 
        for ii=1:N
            for jj=1:dim
                if Positions_ref(ii,jj)>Ub(jj)
                    Positions_ref(ii,jj)=Ub(jj);
                end
                if Positions_ref(ii,jj)<Lb(jj)
                    Positions_ref(ii,jj)=Lb(jj);
                end
            end
        end
        Positions_union=[X;Positions_ref];
        for i=1:N
           fitness_ref(i)= fobj(Positions_ref(i,:));
        end
        fitness_union=[TFitness,fitness_ref];
        [~,idx]=sort(fitness_union);
        XX=Positions_union(idx(1:N),:); 
        fitness11=fitness_union(idx(1:N));   
        if fitness11(1)<fmin1
            fmin1=fitness11(1);
            best=XX(1,:);
        end
    end
    cg_curve(t) = fmin1;
end  
bestFitValue = fmin1;
bestSolution = best;
end
function L=Levy(d)
beta=3/2;
sigma=(gamma(1+beta)*sin(pi*beta/2)/(gamma((1+beta)/2)*beta*2^((beta-1)/2)))^(1/beta);
u=randn(1,d)*sigma;
v=randn(1,d);
step=u./abs(v).^(1/beta);
L=1*step;     
end
function s=simplebounds(s,Lb,Ub)
ns_tmp=s;
I=ns_tmp<Lb;
ns_tmp(I)=Lb(I);

J=ns_tmp>Ub;
ns_tmp(J)=Ub(J);

s=ns_tmp;
end
function shapley_values = calculateShapleyValueTwoPlayers(f)
    shapley_values = zeros(1, 2);
    v = f([]);
    for player_A = 1:2
        coalition_A = player_A;
        f_A = f(coalition_A);
        if player_A == 1
            coalition_AB = [1, 2]; 
        else
            coalition_AB = [2, 1]; 
        end
        f_A_and_B = f(coalition_AB);
        shapley_values(player_A) = 0.5 * (f_A + f_A_and_B - v);
    end
end
